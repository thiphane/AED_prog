package dataStructures.exceptions;

public class EmptyMapException extends RuntimeException {
    public EmptyMapException() {
        super();
    }
}
