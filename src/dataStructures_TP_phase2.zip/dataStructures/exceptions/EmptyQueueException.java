package dataStructures.exceptions;

public class EmptyQueueException extends RuntimeException {
    public EmptyQueueException() {
        super();
    }
}
