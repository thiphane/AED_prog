/**
 * @author Thiphane Silva 69882
 * @author Rodrigo Moura 71429
 */
package campus_app.app;

public enum Order {
    OLD_TO_NEW, NEW_TO_OLD
}
